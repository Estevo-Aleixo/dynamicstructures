#pragma once
#include <qt/qwidget.h>
#include <Ogre.h>

#ifdef QTOGRE_EXPORTS
#define QTOGRE_API __declspec(dllexport)
#else
#define QTOGRE_API __declspec(dllimport)
#endif

class QTOGRE_API QOgreFrame : public QWidget
{
protected:
	Ogre::Root*          root_;
	Ogre::Camera*        camera_;
	Ogre::Viewport*      vp_;
	Ogre::SceneManager*  sceneMgr_;
	Ogre::String         resourcePath_;
	Ogre::RenderWindow*  renderWindow_;
	Ogre::String         ogreWidgetName_;

	void setupResources();
	void initOgre();
	void createRenderWindow();
	void update();

	void createScene();

	void resizeEvent( QResizeEvent *re );
	void paintEvent( QPaintEvent *pe );
	void timerEvent( QTimerEvent *te );

public:
	QOgreFrame( QWidget* parent, const char* name, Qt::WFlags f = 0 );
	virtual ~QOgreFrame();

	Ogre::Root*          getRoot() const;
	Ogre::SceneManager*  getSceneManager() const;
	Ogre::Camera*        getCamera() const;
};