#include "QOgreFrame.h"
#include <iostream>
#include <qt/qlabel.h>

#include <qt/private/qframe_p.h>

QOgreFrame::QOgreFrame( QWidget* parent, const char* name, Qt::WFlags f ) : QFrame( *new QFramePrivate, parent, f) {

	setMinimumWidth(800);
	setMinimumHeight(600);
	renderWindow_ = NULL;
	sceneMgr_ = NULL;
	vp_ = NULL;
	ogreWidgetName_ = name;
	initOgre();
} 

QOgreFrame::~QOgreFrame() {
	delete root_;
}

void QOgreFrame::setupResources()
{
	// Load resource paths from config file
	Ogre::ConfigFile cf;
	try {
		cf.load("resources.cfg");
	} catch ( Ogre::FileNotFoundException* fnfe ) {
		std::cerr << "Error: Could not find resource file 'resources.cfg'" << std::endl;
		std::cerr << "  " << fnfe->getDescription() << std::endl;
		return;
	}

	// Go through all sections & settings in the file
	Ogre::ConfigFile::SectionIterator seci = cf.getSectionIterator();

	Ogre::String secName, typeName, archName;
	while (seci.hasMoreElements())
	{
		secName = seci.peekNextKey();
		Ogre::ConfigFile::SettingsMultiMap *settings = seci.getNext();
		Ogre::ConfigFile::SettingsMultiMap::iterator i;
		for (i = settings->begin(); i != settings->end(); ++i)
		{
			typeName = i->first;
			archName = i->second;
			Ogre::ResourceGroupManager::getSingleton().addResourceLocation(
				archName, typeName, secName);
		}
	}
} 

void QOgreFrame::initOgre() {
	root_ = new Ogre::Root();

	setupResources();

	if(!root_->restoreConfig())
		root_->showConfigDialog();

	root_->initialise(false);
}

void QOgreFrame::createRenderWindow() {
	Ogre::NameValuePairList params;
	params["externalWindowHandle"] = Ogre::StringConverter::toString((size_t)::WindowFromDC(this->getDC()));
	renderWindow_ = root_->createRenderWindow(ogreWidgetName_+"Win", width(), height(), false, &params);
	startTimer(10);
}

void QOgreFrame::resizeEvent( QResizeEvent *re )
{
	if (renderWindow_!=NULL) {
		renderWindow_->resize( width(), height() );
		camera_->setAspectRatio(Ogre::Real(width()) / Ogre::Real(height()));
	}
} 

void QOgreFrame::paintEvent( QPaintEvent *pe ) { 

	if (renderWindow_==NULL) {
		createRenderWindow();
		sceneMgr_ = root_->createSceneManager(Ogre::ST_GENERIC,ogreWidgetName_+"SM");
		camera_ = sceneMgr_->createCamera(ogreWidgetName_+"Cam");
		camera_->setPosition(Ogre::Vector3(0,0,200));
		camera_->lookAt(Ogre::Vector3(0,0,-300));
		camera_->setNearClipDistance(5);
		vp_ = renderWindow_->addViewport(camera_);
		vp_->setBackgroundColour(Ogre::ColourValue(0,0,0));
		camera_->setAspectRatio(Ogre::Real(vp_->getActualWidth()) / Ogre::Real(vp_->getActualHeight()));
		Ogre::MaterialManager::getSingleton().setDefaultTextureFiltering(Ogre::TFO_BILINEAR);
		Ogre::MaterialManager::getSingleton().setDefaultAnisotropy(1);
	}
}


void QOgreFrame::timerEvent( QTimerEvent *te ) {
	update();
} 

void QOgreFrame::update()
{
	if (NULL != renderWindow_){
		Ogre::Root::getSingletonPtr()->_fireFrameStarted();
		renderWindow_->update();
		Ogre::Root::getSingletonPtr()->_fireFrameEnded();
	}
} 

//////////
//////////void QOgreFrame::createScene()
//////////{
//////////	sceneMgr_->setAmbientLight(Ogre::ColourValue(0.6, 0.6, 0.6));
//////////
//////////	// Setup the actual scene
//////////	Ogre::Light* l = sceneMgr_->createLight("MainLight");
//////////	l->setPosition(0, 100, 500);
//////////
//////////	Ogre::Entity* head = sceneMgr_->createEntity("head", "ogrehead.mesh");
//////////	Ogre::SceneNode* headNode = sceneMgr_->getRootSceneNode()->createChildSceneNode();
//////////	headNode->attachObject(head);
//////////
//////////	//temp = headNode;
//////////	headNode->setOrientation(cos(0.5),0,sin(0.5),0);
//////////	camera_->setAutoTracking(true, headNode);
//////////}
//////////
