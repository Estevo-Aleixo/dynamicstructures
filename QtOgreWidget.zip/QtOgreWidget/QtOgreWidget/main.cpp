#include <qt/qapplication.h>
#include <qt/qmainwindow.h>
#include <qt/qframe.h>
#include "QtOgre/QOgreFrame.h"
#include <Ogre.h>

#pragma comment(lib, "QtCore4.lib")
#pragma comment(lib, "QtGui4.lib")
#ifdef _DEBUG
	#pragma comment(lib, "OgreMain_d.lib")
	#pragma comment(lib, "QtOgred.lib")
#else
	#pragma comment(lib, "QtOgre.lib")
	#pragma comment(lib, "OgreMain.lib")
#endif

void createScene(Ogre::SceneManager* sceneMgr) {
	sceneMgr->setAmbientLight(Ogre::ColourValue(0.6, 0.6, 0.6));

	// Setup the actual scene
	Ogre::Light* l = sceneMgr->createLight("MainLight");
	l->setPosition(0, 100, 500);

	Ogre::Entity* head = sceneMgr->createEntity("head", "ogrehead.mesh");
	Ogre::SceneNode* headNode = sceneMgr->getRootSceneNode()->createChildSceneNode();
	headNode->attachObject(head);

	//temp = headNode;
	headNode->setOrientation(cos(0.5),0,sin(0.5),0);
}

int main( int argc, char **argv )
{
	QApplication a( argc, argv );

	QMainWindow mw(NULL);
	a.setActiveWindow( &mw );
	mw.show();

	QOgreFrame w(&mw, "ogre");
	w.setGeometry( 100, 100, 10, 10 );
	w.show();

	//Ogre::SceneManager* sceneMgr = w.getSceneManager();
	//createScene(sceneMgr);

	return a.exec();
}