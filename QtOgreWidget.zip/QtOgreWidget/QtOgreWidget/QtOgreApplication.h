#pragma once

#include <Ogre.h>

#include "OgreFrameListener.h"

#define OIS_DYNAMIC_LIB
#include <OIS/OIS.h>

using namespace Ogre;

class OgreApplication {
public:
	OgreApplication(unsigned long winhandle = 0) : winhandle_(winhandle) {
        mFrameListener = 0;
        mRoot = 0;
		#if OGRE_PLATFORM == OGRE_PLATFORM_APPLE
			mResourcePath = macBundlePath() + "/Contents/Resources/";
		#else
			mResourcePath = "";
		#endif
	}

    virtual ~OgreApplication()
    {
        if (mFrameListener)
            delete mFrameListener;
        if (mRoot)
            delete mRoot;
    }

    virtual void go(void)
    {
        if (!setup()) return;
        mRoot->startRendering();
        // clean up
        destroyScene();
    }

protected:

	unsigned long winhandle_;

    Root *mRoot;
    Camera* mCamera;
    SceneManager* mSceneMgr;
    OgreFrameListener* mFrameListener;
    RenderWindow* mWindow;
    Ogre::String mResourcePath;

    virtual bool setup(void) {
		String pluginsPath;
		#ifndef OGRE_STATIC_LIB
			pluginsPath = mResourcePath + "plugins.cfg";
		#endif

        mRoot = new Root(pluginsPath,  mResourcePath + "ogre.cfg", mResourcePath + "Ogre.log");

        setupResources();

        bool carryOn = configure();
        if (!carryOn) return false;

        chooseSceneManager();
        createCamera();
        createViewports();

        // Set default mipmap level (NB some APIs ignore this)
        TextureManager::getSingleton().setDefaultNumMipmaps(5);

		// Create any resource listeners (for loading screens)
		createResourceListener();
		// Load resources
		loadResources();

		// Create the scene
        createScene();

        createFrameListener();

        return true;

    }

	virtual bool configure(void) {
        if(mRoot->showConfigDialog()) {
            mWindow = mRoot->initialise(true);
            return true;
        }
        else {
            return false;
        }
    }

    virtual void chooseSceneManager(void) {
        // Create the SceneManager, in this case a generic one
        mSceneMgr = mRoot->createSceneManager(ST_GENERIC, "Main Scene Manager");
    }

    virtual void createCamera(void) {
        // Create the camera
        mCamera = mSceneMgr->createCamera("Main Camera");

        // Position it at 500 in Z direction
        mCamera->setPosition(Vector3(0,2,5));
        // Look back along -Z
        mCamera->lookAt(Vector3(0,0,-5));
        mCamera->setNearClipDistance(1);
    }

    virtual void createFrameListener(void) {
        mFrameListener= new OgreFrameListener(mWindow, mCamera);
        mFrameListener->showDebugOverlay(true);
        mRoot->addFrameListener(mFrameListener);
    }

    virtual void createScene(void) = 0; // pure virtual - this has to be overridden

    virtual void destroyScene(void){
	}

    virtual void createViewports(void) {
        // Create one viewport, entire window
        Viewport* vp = mWindow->addViewport(mCamera);
        vp->setBackgroundColour(ColourValue(0,0,0));

        // Alter the camera aspect ratio to match the viewport
        mCamera->setAspectRatio(
            Real(vp->getActualWidth()) / Real(vp->getActualHeight()));
    }

    virtual void setupResources(void) {
        ConfigFile cf;
        cf.load(mResourcePath + "resources.cfg");

		ConfigFile::SectionIterator seci = cf.getSectionIterator();

        String secName, typeName, archName;
        while (seci.hasMoreElements()) {
            secName = seci.peekNextKey();
            ConfigFile::SettingsMultiMap *settings = seci.getNext();
            ConfigFile::SettingsMultiMap::iterator i;
            for (i = settings->begin(); i != settings->end(); ++i) {
                typeName = i->first;
                archName = i->second;
                ResourceGroupManager::getSingleton().addResourceLocation(
                    archName, typeName, secName);
            }
        }
    }

	virtual void createResourceListener(void) {
	}

	virtual void loadResources(void) {
		ResourceGroupManager::getSingleton().initialiseAllResourceGroups();
	}


};
