#include <QtGui/QApplication>
#include "qttest.h"
#include "QtOgre/QOgreFrame.h"


int main(int argc, char *argv[])
{
	QApplication a( argc, argv );

	QMainWindow mw(NULL);
	a.setActiveWindow( &mw );
	mw.show();

	QOgreFrame w(&mw, "ogre");
	w.setGeometry( 100, 100, 10, 10 );
	w.show();

	return a.exec();
	
	
	
	//QApplication a(argc, argv);
 //   //QtTest w(NULL);
	//QMainWindow w(NULL);
	//a.setActiveWindow(&w);
 //   w.show();

 //   //a.connect(&a, SIGNAL(lastWindowClosed()), &a, SLOT(quit()));

	//QOgreFrame of(&w, "ogre");
	//of.setGeometry( 100, 100, 10, 10 );
	//of.show();

	//return a.exec();
}
