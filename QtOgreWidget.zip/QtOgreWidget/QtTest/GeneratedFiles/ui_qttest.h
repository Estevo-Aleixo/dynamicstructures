#ifndef UI_QTTEST_H
#define UI_QTTEST_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QMainWindow>
#include <QtGui/QMenuBar>
#include <QtGui/QStatusBar>
#include <QtGui/QToolBar>
#include <QtGui/QWidget>

class Ui_QtTestClass
{
public:
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QWidget *centralWidget;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *QtTestClass)
    {
    QtTestClass->setObjectName(QString::fromUtf8("QtTestClass"));
    QtTestClass->setObjectName("QtTestClass");
    QtTestClass->resize(QSize(600, 400).expandedTo(QtTestClass->minimumSizeHint()));
    menuBar = new QMenuBar(QtTestClass);
    menuBar->setObjectName(QString::fromUtf8("menuBar"));
    QtTestClass->setMenuBar(menuBar);
    mainToolBar = new QToolBar(QtTestClass);
    mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
    QtTestClass->addToolBar(mainToolBar);
    centralWidget = new QWidget(QtTestClass);
    centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
    QtTestClass->setCentralWidget(centralWidget);
    statusBar = new QStatusBar(QtTestClass);
    statusBar->setObjectName(QString::fromUtf8("statusBar"));
    QtTestClass->setStatusBar(statusBar);
    retranslateUi(QtTestClass);

    QMetaObject::connectSlotsByName(QtTestClass);
    } // setupUi

    void retranslateUi(QMainWindow *QtTestClass)
    {
    QtTestClass->setWindowTitle(QApplication::translate("QtTestClass", "QtTest", 0, QApplication::UnicodeUTF8));
    Q_UNUSED(QtTestClass);
    } // retranslateUi

};

namespace Ui {
    class QtTestClass: public Ui_QtTestClass {};
} // namespace Ui

#endif // UI_QTTEST_H
