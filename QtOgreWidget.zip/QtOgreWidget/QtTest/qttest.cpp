#include "qttest.h"
#include "QtOgre/QOgreFrame.h"

QtTest::QtTest(QWidget *parent, Qt::WFlags flags)
    : QMainWindow(parent, flags)
{
	ui.setupUi(this);
}

QtTest::~QtTest()
{

}

void QtTest::createOgreWidget() {
	//QOgreFrame of(this, "ogre");
	//of.setGeometry( 100, 100, 10, 10 );
	//of.show();
}